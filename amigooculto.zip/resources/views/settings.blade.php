@extends('layout.app')
@section('title','Configurações')
@section('content')
  <div class="container">
    <div class="row">
      <div class="col-md-8 offset-2">
        <painel titulo="Configurações" classe="fa fa-lg fa-settings">
          <passport-at></passport-at>
        </painel>
      </div>
    </div>
  </div>

@endsection
