<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Participantes;
class PagesController extends Controller
{
    public function index(){
        $dados = Participantes::orderBy('nome','asc')
              ->get();
        return view('inicio')->with('usuarios',$dados);
    }
    
    public function viewSorteio(){
      $dados = Participantes::where('sorteou', 0)
              ->orderBy('nome','asc')
              ->get();

      return view('sorteio')->with('nomes',$dados);
    }
    


}
