<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Participantes;
class ApiController extends Controller
{
    public function viewParticipantes()
    {
        $dados = Participantes::all();
        return json_encode($dados);
    }
    public function viewResultado(){
        return Participantes::select('nome', 'segredo')->get()->toJson();
    }
}
