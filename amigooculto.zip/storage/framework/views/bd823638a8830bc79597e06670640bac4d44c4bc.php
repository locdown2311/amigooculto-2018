<?php $__env->startSection('title','Configurações'); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-8 offset-2">
        <painel titulo="Configurações" classe="fa fa-lg fa-settings">
          <passport-at></passport-at>
        </painel>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>