<?php $__env->startSection('title','Resultados'); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-8 offset-2">
        <painel titulo="Resultado do amigo oculto" classe="fa fa-lg fa-users sorteio">
          <resultados :users="<?php echo e($participantes); ?>"></resultados>
        </painel>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>