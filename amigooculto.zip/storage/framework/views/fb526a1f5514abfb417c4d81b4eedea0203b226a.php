<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<div class="panel panel-default">
					<div class="panel-heading"><i class="fa fa-lg fa-info introducao"></i> Instruções</div>
						<div class="panel-body">

						<p>Seja bem vindo</p>						
						<p>Para realizar o sorteio vá na aba "Realizar sorteio" e selecione o seu
						nome na barra de seleção.</p>
						<p>Apos selecionar o nome, verifique se o mesmo está correto para não causar 
						problemas para os demais participantes</p>
						<p>Apos realizado a verificação,clique no botão de realizar sorteio e 
						irá aparecer uma pequena mensagem verde com o nome do seu Amigo Oculto </p>
						<p>Depois de decorar o nome do seu sorteado, clique no <strong style="color : green" >X</strong> no canto direito da mensagem para
						dar continuidade ao proximo participante</p>
					</div>
				</div>
			</div>
		</div>
		
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>