<?php $__env->startSection('title','Resultados'); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
          <div class="panel-heading"><i class="fa fa-lg fa-users sorteio"> </i> Resultado do amigo oculto</div>
          <div class="panel-body">
            <?php if(Session::has('message')): ?>
                <div class="alert alert-success alert-dismissable fade in">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                  <?php echo e(Session::get('message')); ?>

                </div>
            <?php endif; ?>
            <table class="table table-bordered">
            <thead>
                <tr>
                <th>Nome</th>
                <th>Segredo</th>
                <th>Ações</th>
                </tr>
          </thead>
         <tbody>
         <?php $__currentLoopData = $participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->nome); ?></td>
                <td><?php echo e($user->segredo); ?></td>
                <td>
                                <form class="form-inline" action="" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button onclick="return confirm('Deseja realmente excluir ?')" type="submit" class="btn btn-sm btn-danger">Deletar</button>
                                  </form>
                </td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
  </table>

            
          </div>
        </div>
      </div>


    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>