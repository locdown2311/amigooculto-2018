<?php $__env->startSection('title','Sorteio'); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-8 offset-2">
        <painel titulo="Sorteio" classe="fa fa-lg fa-users sorteio">
            <?php if(Session::has('retorno')): ?>
            <sorteado :dado="<?php echo e(Session::get('retorno')); ?>"></sorteado>
            <?php endif; ?>
            <?php if(count($nomes) <= 0): ?>
                  <div class="alert alert-warning">
                    <p>Não existem participantes não sorteados </p>
                  </div>
            <?php else: ?>
            
            <form class="form-horizontal" method="POST" action="<?php echo e(route('sorteio.realiza')); ?>">
              <?php echo e(csrf_field()); ?>


                <label for="nome" class="col-md-4 control-label">Seu nome : </label>
                <div class="form-group">
                  <div class="col-md-6">
                      <select id="nome" class="form-control" name="nome" required>
                        <?php $__currentLoopData = $nomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($id->nome); ?>"><?php echo e($id->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                 </div>
              </div>

              <div class="form-group">
                <div class="col-md-6">
                  <button type="submit" onclick="return confirm('O nome escolhido está certo?')" class="btn btn-primary">
                    Realizar sorteio
                  </button>
                </div>
              </div>
              <?php endif; ?>
            </form>

        </painel>
        </div>
      </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>