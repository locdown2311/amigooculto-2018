<?php $__env->startSection('title','Cadastro'); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-2"></div>
      <div class="col-xs-12 col-md-8">
        <painel titulo="Cadastrar participantes" classe="fa fa-lg fa-user-plus cadastro">
            <?php if(Session::has('usuarios')): ?>
            <alerta :dado="<?php echo e(Session::get('usuarios')); ?>"></alerta>
            <?php endif; ?>
            <form class="form-horizontal" method="POST" action="<?php echo e(route('cadastro.realiza')); ?>">
                <?php echo e(csrf_field()); ?>

  
                <div class="form-group <?php echo e($errors->has('nome') ? ' has-error' : ''); ?>">
                  <label for="nome" class="col-md-4 control-label">Nome do participante :</label>
                  <div class="col-md-6">
                    <input id="nome" type="text" class="form-control" name="nome" value="<?php echo e(old('nome')); ?>" placeholder="Evite acentos" required autofocus>
  
                    <?php if($errors->has('nome')): ?>
                      <span class="help-block">
                        <strong><?php echo e($errors->first('nome')); ?></strong>
                      </span>
                    <?php endif; ?>
                  </div>
                </div>
  
                <div class="form-group">
                  
                  <div class="col-md-6 ">
                    <button type="submit" class="btn btn-primary">
                      Cadastrar participante
                    </button>
                  </div>
                </div>
            </form>
        </painel>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>